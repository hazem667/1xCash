import logging
import os
from telegram.ext import Application

from database.db import init_db
from handlers import deposit, withdraw, support, order_actions, admin_panel, myops, user_menu

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger(__name__)


async def post_init(app):
    await init_db()
    logger.info("✅ قاعدة البيانات جاهزة")


def main():
    token = os.getenv("BOT_TOKEN")
    if not token:
        raise ValueError("BOT_TOKEN غير موجود في متغيرات البيئة!")

    app = (
        Application.builder()
        .token(token)
        .post_init(post_init)
        .build()
    )

    # ── الترتيب مهم جداً ──────────────────────────
    # group=0 : Admin panel (أعلى أولوية)
    for h in admin_panel.get_handlers():
        app.add_handler(h, group=0)

    # group=1 : Conversations (deposit / withdraw / support)
    app.add_handler(deposit.get_handler(), group=1)
    app.add_handler(withdraw.get_handler(), group=1)
    app.add_handler(support.get_handler(), group=1)

    # group=2 : Order actions callbacks + relay chat
    for h in order_actions.get_handlers():
        app.add_handler(h, group=2)

    # group=3 : My operations pagination
    for h in myops.get_handlers():
        app.add_handler(h, group=3)

    # group=4 : User menu — الراوتر الرئيسي + /start
    for h in user_menu.get_handlers():
        app.add_handler(h, group=4)

    logger.info("✅ البوت شغال...")
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
